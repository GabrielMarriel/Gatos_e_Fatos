function scrollSelection() {
  const nextSelection = document.querySelector('.page2');
  nextSelection.scrollIntoView({ behavior: 'smooth' });
}